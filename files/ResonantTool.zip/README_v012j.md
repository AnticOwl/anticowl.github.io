ResonantTool v0.12j — Keyboard double-input fix only.

Use the ImGui Win32 WM_CHAR/WM_KEY* path when Windows legacy keyboard messages are enabled, or the WM_INPUT Raw Input path when the game registers RIDEV_NOLEGACY. Never feed both paths for the same key. The existing F11 toggle, mouse routing, lighting, PP and LOD are unchanged.

Source package; compile using Build.cmd on Windows.
